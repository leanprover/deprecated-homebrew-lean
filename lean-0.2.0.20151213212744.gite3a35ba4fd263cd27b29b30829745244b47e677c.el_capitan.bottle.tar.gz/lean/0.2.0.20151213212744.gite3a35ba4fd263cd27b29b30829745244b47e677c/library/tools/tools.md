tools
=====

Various additional tools.

* [helper_tactics](helper_tactics.lean) : useful tactics