data.rat
========

The rational numbers.

* [basic](basic.lean) : the rationals as a field
* [order](order.lean) : the order relations and the sign function
* [bigops](bigops.lean)