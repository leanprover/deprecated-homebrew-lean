theories.combinatorics
======================

* [choose](choose.lean)
