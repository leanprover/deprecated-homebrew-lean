data.fintype
============

Finite types.

* [basic](basic.lean) 
* [function](function.lean)
* [card](card.lean)
